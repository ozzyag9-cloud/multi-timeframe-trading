"""
Integration tests for the entire system
"""

import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import tempfile
import os

from enhanced_multi_timeframe import EntryExitPredictor
from ternary_algorithm import TernarySignalFilter
from web_interface import app
from config import config

class TestIntegration:
    """Integration tests for the complete system"""
    
    def setUp(self):
        """Setup test environment"""
        self.predictor = EntryExitPredictor()
        self.filter = TernarySignalFilter()
        self.client = app.test_client()
    
    def test_end_to_end_analysis(self):
        """Test complete analysis pipeline"""
        # Run analysis
        results = self.predictor.analyze_asset('BTC')
        
        assert '5m' in results or '1h' in results
        assert '24h' in results
        
        # Check results structure
        for timeframe, result in results.items():
            if 'error' not in result:
                assert 'prediction' in result
                assert 'entry_exit' in result
                assert 'causal' in result
                assert 'backtest' in result
    
    def test_ternary_filter_integration(self):
        """Test ternary filter with real data"""
        # Get data
        df = self.predictor.timeframe_predictor.data_fetcher.fetch_all_timeframes('BTC').get('1h')
        
        if df is None:
            pytest.skip("No data available")
        
        # Generate signals
        entry, exit_ = self.predictor.causal_engine.generate_signals(df)
        
        # Apply filter
        filtered_entry, filtered_exit = self.filter.filter_signals(df, entry, exit_)
        
        # Verify filtering reduces signals
        assert filtered_entry.sum() <= entry.sum()
        assert filtered_exit.sum() <= exit_.sum()
        
        # Verify filter ratio is reasonable
        total_original = entry.sum() + exit_.sum()
        total_filtered = filtered_entry.sum() + filtered_exit.sum()
        filter_ratio = total_filtered / total_original if total_original > 0 else 0
        
        assert 0 <= filter_ratio <= 1
    
    def test_web_api_endpoints(self):
        """Test web API endpoints"""
        # Test analyze endpoint
        response = self.client.post('/api/analyze', 
                                   json={'asset': 'BTC'})
        assert response.status_code == 200
        data = response.json
        assert data['status'] == 'success'
        assert data['asset'] == 'BTC'
        
        # Test signals endpoint
        response = self.client.get('/api/signals/BTC')
        assert response.status_code in [200, 404]
        
        # Test chart endpoint
        response = self.client.get('/api/chart/BTC/1h')
        assert response.status_code in [200, 404]
        
        # Test summary endpoint
        response = self.client.get('/api/summary/BTC')
        assert response.status_code in [200, 404]
    
    def test_data_persistence(self):
        """Test data caching and persistence"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create cache directory
            cache_dir = os.path.join(tmpdir, 'cache')
            os.makedirs(cache_dir)
            
            # Fetch data with cache
            from enhanced_multi_timeframe import MultiTimeframeDataFetcher
            fetcher = MultiTimeframeDataFetcher(cache_dir=cache_dir)
            
            # First fetch
            df1 = fetcher.fetch_all_timeframes('BTC').get('1h')
            
            # Second fetch should use cache
            df2 = fetcher.fetch_all_timeframes('BTC').get('1h')
            
            if df1 is not None and df2 is not None:
                assert len(df1) == len(df2)
    
    def test_signal_quality_metrics(self):
        """Test signal quality metrics"""
        # Get data
        df = self.predictor.timeframe_predictor.data_fetcher.fetch_all_timeframes('BTC').get('1h')
        
        if df is None:
            pytest.skip("No data available")
        
        # Get signal quality
        quality = self.filter.get_signal_quality(df, 'BUY', len(df) - 1)
        
        assert 'signal_strength' in quality
        assert 'stage_scores' in quality
        assert 'recommendation' in quality
        assert 'risk_level' in quality
        
        # Verify scores are in range
        assert 0 <= quality['signal_strength'] <= 1
        for score in quality['stage_scores'].values():
            assert 0 <= score <= 1
    
    def test_config_loading(self):
        """Test configuration loading"""
        from config import config
        
        assert hasattr(config, 'DEFAULT_ASSET')
        assert hasattr(config, 'DEFAULT_TIMEFRAME')
        assert hasattr(config, 'SUPPORTED_ASSETS')
        assert hasattr(config, 'SUPPORTED_TIMEFRAMES')
        
        assert config.DEFAULT_ASSET in config.SUPPORTED_ASSETS
        assert config.DEFAULT_TIMEFRAME in config.SUPPORTED_TIMEFRAMES

if __name__ == "__main__":
    pytest.main([__file__, '-v'])
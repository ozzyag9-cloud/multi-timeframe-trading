# Deployment Guide

## Quick Deployment

### Option 1: Docker (Recommended)
```bash
docker-compose up -d
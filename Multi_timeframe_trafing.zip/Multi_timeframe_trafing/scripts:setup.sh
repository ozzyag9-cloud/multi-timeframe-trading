#!/bin/bash
# setup.sh - Complete project setup

set -e

echo "🚀 Setting up Multi-Timeframe Trading Predictor"
echo "================================================"
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check Python version
echo "📋 Checking Python version..."
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "   Python $python_version"

if [[ $(echo $python_version | cut -d. -f1) -lt 3 ]] || [[ $(echo $python_version | cut -d. -f2) -lt 8 ]]; then
    echo -e "${RED}❌ Python 3.8+ required${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Python version OK${NC}"
echo ""

# Create virtual environment
echo "📦 Creating virtual environment..."
if [ -d "venv" ]; then
    echo "   Virtual environment already exists"
else
    python3 -m venv venv
    echo -e "${GREEN}✅ Virtual environment created${NC}"
fi
echo ""

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate
echo -e "${GREEN}✅ Virtual environment activated${NC}"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
pip install --upgrade pip > /dev/null 2>&1
pip install -r requirements.txt
echo -e "${GREEN}✅ Dependencies installed${NC}"
echo ""

# Create directories
echo "📁 Creating directories..."
mkdir -p cache outputs logs templates static/css static/js docs
echo -e "${GREEN}✅ Directories created${NC}"
echo ""

# Create .env file
echo "📝 Creating .env file..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo -e "${YELLOW}⚠️  Please edit .env with your tokens${NC}"
else
    echo "   .env already exists"
fi
echo ""

# Make scripts executable
echo "🔧 Making scripts executable..."
chmod +x scripts/*.sh
chmod +x run.py
echo -e "${GREEN}✅ Scripts executable${NC}"
echo ""

# Run tests
echo "🧪 Running tests..."
python -c "from ternary_algorithm import TernarySignalFilter; print('   ✅ Ternary Algorithm loaded')"
python -c "from enhanced_multi_timeframe import EntryExitPredictor; print('   ✅ Predictor loaded')"
python -c "from web_interface import app; print('   ✅ Web Interface loaded')"
python -c "from telegram_bot import main; print('   ✅ Telegram Bot loaded')"
echo -e "${GREEN}✅ All modules loaded${NC}"
echo ""

# Final message
echo "================================================"
echo -e "${GREEN}✅ Setup complete!${NC}"
echo ""
echo "Next steps:"
echo "1. Edit .env with your TELEGRAM_BOT_TOKEN"
echo "2. Run: ./scripts/start.sh"
echo "3. Open browser: http://localhost:5000"
echo ""
echo "⚠️  Remember: Educational & Personal Use Only - NOT Financial Advice"
echo "================================================"
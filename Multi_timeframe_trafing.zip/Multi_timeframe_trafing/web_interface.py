# web_interface.py
"""
Multi-Timeframe Trading Predictor - Web Interface
Educational & Personal Use Only - NOT Financial Advice
"""

from flask import Flask, render_template, jsonify, request, send_file
from flask_cors import CORS
from flask_socketio import SocketIO, emit
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import plotly.graph_objs as go
from plotly.subplots import make_subplots
import plotly.utils
import threading
import time
import os
from pathlib import Path

from enhanced_multi_timeframe import (
    EntryExitPredictor, 
    MultiTimeframePredictor,
    MultiTimeframeDataFetcher,
    CausalAnalysisEngine
)

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# Initialize systems
predictor = EntryExitPredictor()
timeframe_predictor = MultiTimeframePredictor()
data_fetcher = MultiTimeframeDataFetcher()
causal_engine = CausalAnalysisEngine()

# Global state
analysis_cache = {}
active_asset = 'BTC'
active_timeframe = '1h'
auto_update_enabled = True
update_interval = 60  # seconds

# ============================================================
# ROUTES
# ============================================================

@app.route('/')
def index():
    """Main dashboard"""
    return render_template('dashboard.html')

@app.route('/api/analyze', methods=['POST'])
def analyze():
    """Run analysis for an asset"""
    global analysis_cache, active_asset
    
    data = request.json
    asset = data.get('asset', 'BTC')
    active_asset = asset
    
    try:
        # Run analysis
        results = predictor.analyze_asset(asset)
        
        # Get all timeframe data
        timeframe_data = data_fetcher.fetch_all_timeframes(asset)
        
        # Prepare response
        response = {
            'status': 'success',
            'asset': asset,
            'timestamp': datetime.now().isoformat(),
            'results': results,
            'timeframe_data': {
                tf: {
                    'last_price': df['close'].iloc[-1] if df is not None else None,
                    'data_points': len(df) if df is not None else 0
                }
                for tf, df in timeframe_data.items()
                if df is not None
            }
        }
        
        analysis_cache[asset] = response
        
        # Emit update via WebSocket
        socketio.emit('analysis_update', response)
        
        return jsonify(response)
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@app.route('/api/signals/<asset>')
def get_signals(asset):
    """Get current signals for asset"""
    if asset not in analysis_cache:
        return jsonify({'status': 'error', 'message': 'No analysis available'}), 404
    
    data = analysis_cache[asset]
    signals = {}
    
    for timeframe, result in data['results'].items():
        if 'entry_exit' in result and 'error' not in result['entry_exit']:
            ee = result['entry_exit']
            signals[timeframe] = {
                'direction': ee['direction'],
                'entry_price': ee['entry_price'],
                'stop_loss': ee['stop_loss'],
                'take_profit': ee['take_profit'],
                'confidence': result['prediction'].get('confidence', 0),
                'risk_reward': ee.get('risk_reward_ratio', 0)
            }
    
    return jsonify({
        'status': 'success',
        'asset': asset,
        'signals': signals
    })

@app.route('/api/chart/<asset>/<timeframe>')
def get_chart(asset, timeframe):
    """Generate interactive chart for asset and timeframe"""
    try:
        # Fetch data
        df = data_fetcher.fetch_all_timeframes(asset).get(timeframe)
        
        if df is None or df.empty:
            return jsonify({'status': 'error', 'message': 'No data available'}), 404
        
        # Get analysis if available
        analysis = analysis_cache.get(asset, {}).get('results', {}).get(timeframe, {})
        
        # Create subplots
        fig = make_subplots(
            rows=4, cols=1,
            shared_xaxes=True,
            vertical_spacing=0.05,
            row_heights=[0.4, 0.2, 0.2, 0.2],
            subplot_titles=(
                f'{asset} - {timeframe}',
                'Volume',
                'RSI',
                'MACD'
            )
        )
        
        # 1. Price chart with Bollinger Bands
        # Calculate Bollinger Bands
        sma20 = df['close'].rolling(20).mean()
        std20 = df['close'].rolling(20).std()
        bb_upper = sma20 + (std20 * 2)
        bb_lower = sma20 - (std20 * 2)
        
        # Candlestick
        fig.add_trace(
            go.Candlestick(
                x=df.index,
                open=df['open'],
                high=df['high'],
                low=df['low'],
                close=df['close'],
                name='Price'
            ),
            row=1, col=1
        )
        
        # Bollinger Bands
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=bb_upper,
                name='BB Upper',
                line=dict(color='rgba(0,200,0,0.3)', dash='dash')
            ),
            row=1, col=1
        )
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=bb_lower,
                name='BB Lower',
                line=dict(color='rgba(200,0,0,0.3)', dash='dash'),
                fill='tonexty'
            ),
            row=1, col=1
        )
        
        # Add entry/exit levels if available
        if 'entry_exit' in analysis and 'error' not in analysis['entry_exit']:
            ee = analysis['entry_exit']
            
            fig.add_hline(
                y=ee['entry_price'],
                line_dash="dash",
                line_color="green",
                annotation_text="Entry",
                annotation_position="top left",
                row=1, col=1
            )
            fig.add_hline(
                y=ee['stop_loss'],
                line_dash="dash",
                line_color="red",
                annotation_text="Stop Loss",
                annotation_position="bottom left",
                row=1, col=1
            )
            fig.add_hline(
                y=ee['take_profit'],
                line_dash="dash",
                line_color="blue",
                annotation_text="Take Profit",
                annotation_position="top right",
                row=1, col=1
            )
        
        # 2. Volume
        colors = ['green' if df['close'].iloc[i] >= df['open'].iloc[i] else 'red' 
                 for i in range(len(df))]
        fig.add_trace(
            go.Bar(
                x=df.index,
                y=df['volume'],
                name='Volume',
                marker_color=colors
            ),
            row=2, col=1
        )
        
        # 3. RSI
        rsi = causal_engine.calculate_rsi(df['close'])
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=rsi,
                name='RSI',
                line=dict(color='purple', width=2)
            ),
            row=3, col=1
        )
        fig.add_hline(y=70, line_dash="dash", line_color="red", row=3, col=1)
        fig.add_hline(y=30, line_dash="dash", line_color="green", row=3, col=1)
        fig.add_hrect(y0=30, y1=70, fillcolor="gray", opacity=0.1, row=3, col=1)
        
        # 4. MACD
        exp1 = df['close'].ewm(span=12, adjust=False).mean()
        exp2 = df['close'].ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        macd_signal = macd.ewm(span=9, adjust=False).mean()
        macd_hist = macd - macd_signal
        
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=macd,
                name='MACD',
                line=dict(color='blue', width=2)
            ),
            row=4, col=1
        )
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=macd_signal,
                name='Signal',
                line=dict(color='red', width=2)
            ),
            row=4, col=1
        )
        fig.add_trace(
            go.Bar(
                x=df.index,
                y=macd_hist,
                name='Histogram',
                marker_color='gray',
                opacity=0.5
            ),
            row=4, col=1
        )
        
        # Update layout
        fig.update_layout(
            height=800,
            title_text=f"{asset} - {timeframe} Analysis",
            showlegend=True,
            template='plotly_dark',
            hovermode='x unified'
        )
        
        # Update axes
        fig.update_xaxes(rangeslider_visible=False)
        
        # Convert to JSON
        graph_json = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
        
        return jsonify({
            'status': 'success',
            'chart': graph_json
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@app.route('/api/causal/<asset>/<timeframe>')
def get_causal_analysis(asset, timeframe):
    """Get causal analysis for asset and timeframe"""
    try:
        # Fetch data
        df = data_fetcher.fetch_all_timeframes(asset).get(timeframe)
        
        if df is None or df.empty:
            return jsonify({'status': 'error', 'message': 'No data available'}), 404
        
        # Run causal analysis
        causal = causal_engine.identify_causal_factors(df)
        
        if 'error' in causal:
            return jsonify({'status': 'error', 'message': causal['error']}), 400
        
        return jsonify({
            'status': 'success',
            'causal': causal
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@app.route('/api/backtest/<asset>/<timeframe>')
def get_backtest(asset, timeframe):
    """Get backtest results for asset and timeframe"""
    try:
        # Fetch data
        df = data_fetcher.fetch_all_timeframes(asset).get(timeframe)
        
        if df is None or df.empty:
            return jsonify({'status': 'error', 'message': 'No data available'}), 404
        
        # Generate signals
        entry_signals, exit_signals = causal_engine.generate_signals(df)
        
        # Run backtest
        backtest = predictor.validation_engine.backtest_signals(
            df, entry_signals, exit_signals
        )
        
        return jsonify({
            'status': 'success',
            'backtest': backtest
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@app.route('/api/timeframes')
def get_timeframes():
    """Get available timeframes"""
    return jsonify({
        'status': 'success',
        'timeframes': ['5m', '15m', '1h', '3h', '12h', '24h']
    })

@app.route('/api/assets')
def get_assets():
    """Get available assets"""
    return jsonify({
        'status': 'success',
        'assets': ['BTC', 'ETH', 'SOL']
    })

@app.route('/api/summary/<asset>')
def get_summary(asset):
    """Get market summary for asset"""
    if asset not in analysis_cache:
        return jsonify({'status': 'error', 'message': 'No analysis available'}), 404
    
    data = analysis_cache[asset]
    results = data['results']
    
    # Calculate summary stats
    total_timeframes = len(results)
    bullish = sum(1 for r in results.values() 
                  if 'entry_exit' in r and 'error' not in r['entry_exit']
                  and r['entry_exit'].get('direction') == 'BUY')
    bearish = total_timeframes - bullish
    
    avg_confidence = np.mean([
        r['prediction'].get('confidence', 0)
        for r in results.values()
        if 'prediction' in r
    ]) if results else 0
    
    best_timeframe = max(
        [(tf, r['prediction'].get('confidence', 0)) 
         for tf, r in results.items()
         if 'prediction' in r],
        key=lambda x: x[1],
        default=(None, 0)
    )
    
    return jsonify({
        'status': 'success',
        'summary': {
            'asset': asset,
            'total_timeframes': total_timeframes,
            'bullish': bullish,
            'bearish': bearish,
            'avg_confidence': avg_confidence,
            'market_sentiment': 'BULLISH' if bullish > bearish else 'BEARISH',
            'best_timeframe': best_timeframe[0],
            'best_confidence': best_timeframe[1],
            'last_update': data.get('timestamp', '')
        }
    })

@app.route('/api/export/<asset>/<format>')
def export_data(asset, format):
    """Export data in various formats"""
    if asset not in analysis_cache:
        return jsonify({'status': 'error', 'message': 'No analysis available'}), 404
    
    data = analysis_cache[asset]
    
    if format == 'json':
        return jsonify(data)
    
    elif format == 'csv':
        # Create CSV of signals
        rows = []
        for timeframe, result in data['results'].items():
            if 'entry_exit' in result and 'error' not in result['entry_exit']:
                ee = result['entry_exit']
                rows.append({
                    'Timeframe': timeframe,
                    'Direction': ee['direction'],
                    'Entry': ee['entry_price'],
                    'Stop Loss': ee['stop_loss'],
                    'Take Profit': ee['take_profit'],
                    'Confidence': result['prediction'].get('confidence', 0),
                    'Risk/Reward': ee.get('risk_reward_ratio', 0)
                })
        
        df = pd.DataFrame(rows)
        return df.to_csv(index=False)
    
    return jsonify({'status': 'error', 'message': 'Invalid format'}), 400

# ============================================================
# WEBSOCKET EVENTS
# ============================================================

@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    print(f"Client connected: {request.sid}")
    emit('connected', {'status': 'success'})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    print(f"Client disconnected: {request.sid}")

@socketio.on('start_auto_update')
def handle_auto_update(data):
    """Start auto-update for an asset"""
    global auto_update_enabled, active_asset
    
    asset = data.get('asset', 'BTC')
    interval = data.get('interval', 60)
    
    active_asset = asset
    auto_update_enabled = True
    
    # Start background thread
    def update_loop():
        while auto_update_enabled:
            try:
                # Run analysis
                results = predictor.analyze_asset(asset)
                
                # Prepare update
                update_data = {
                    'asset': asset,
                    'timestamp': datetime.now().isoformat(),
                    'results': results
                }
                
                # Emit update
                socketio.emit('auto_update', update_data)
                
                # Wait for next update
                time.sleep(interval)
                
            except Exception as e:
                print(f"Auto-update error: {e}")
                time.sleep(interval)
    
    # Start in background
    thread = threading.Thread(target=update_loop)
    thread.daemon = True
    thread.start()
    
    emit('auto_update_started', {
        'status': 'success',
        'asset': asset,
        'interval': interval
    })

@socketio.on('stop_auto_update')
def handle_stop_auto_update():
    """Stop auto-update"""
    global auto_update_enabled
    auto_update_enabled = False
    emit('auto_update_stopped', {'status': 'success'})

# ============================================================
# MAIN
# ============================================================

if __name__ == '__main__':
    print("\n" + "="*60)
    print("🚀 MULTI-TIMEFRAME TRADING PREDICTOR - WEB INTERFACE")
    print("Educational & Personal Use Only - NOT Financial Advice")
    print("="*60)
    print("\n📍 Web Interface: http://localhost:5000")
    print("📊 Dashboard: http://localhost:5000")
    print("🔄 Auto-Update: Enabled (60s interval)")
    print("\nPress Ctrl+C to stop\n")
    print("="*60)
    
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
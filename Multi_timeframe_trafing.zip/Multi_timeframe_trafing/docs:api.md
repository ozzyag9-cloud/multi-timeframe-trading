# API Documentation

## REST API Endpoints

### Analysis
- `POST /api/analyze` - Run analysis for an asset
- `GET /api/signals/<asset>` - Get current signals
- `GET /api/summary/<asset>` - Get market summary

### Charts
- `GET /api/chart/<asset>/<timeframe>` - Get chart data
- `GET /api/causal/<asset>/<timeframe>` - Get causal analysis

### Data
- `GET /api/backtest/<asset>/<timeframe>` - Get backtest results
- `GET /api/export/<asset>/<format>` - Export data

## WebSocket Events

### Client → Server
- `start_auto_update` - Start auto-updates
- `stop_auto_update` - Stop auto-updates

### Server → Client
- `analysis_update` - New analysis data
- `auto_update` - Auto-update notification

## Telegram Bot Commands

### Analysis
- `/signals <asset>` - Trading signals
- `/analyze <asset> <timeframe>` - Detailed analysis
- `/alltimeframes <asset>` - All timeframe summary

### Advanced
- `/causal <asset> <timeframe>` - Causal analysis
- `/backtest <asset> <timeframe>` - Backtest results

### Utility
- `/summary <asset>` - Market summary
- `/chart <asset> <timeframe>` - Generate chart
- `/subscribe <asset>` - Auto-updates
- `/unsubscribe` - Stop updates
- `/settings` - Configure bot
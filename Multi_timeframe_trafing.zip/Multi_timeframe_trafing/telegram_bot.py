# telegram_bot.py
"""
Multi-Timeframe Trading Predictor - Telegram Bot
Educational & Personal Use Only - NOT Financial Advice
"""

import os
import logging
from datetime import datetime
import json
import asyncio
from typing import Dict, List, Optional
import pandas as pd
import numpy as np
from io import BytesIO

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, 
    CommandHandler, 
    CallbackQueryHandler, 
    ContextTypes,
    MessageHandler,
    filters
)

from enhanced_multi_timeframe import (
    EntryExitPredictor,
    MultiTimeframePredictor,
    MultiTimeframeDataFetcher,
    CausalAnalysisEngine
)

# Configuration
BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')

# Initialize
predictor = EntryExitPredictor()
timeframe_predictor = MultiTimeframePredictor()
data_fetcher = MultiTimeframeDataFetcher()
causal_engine = CausalAnalysisEngine()

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ============================================================
# COMMAND HANDLERS
# ============================================================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send welcome message"""
    welcome = """
🤖 **Multi-Timeframe Trading Predictor Bot**

Welcome! I analyze cryptocurrency markets across multiple timeframes and provide entry/exit predictions.

**Available Commands:**
/signals [asset] - Get trading signals for all timeframes
/analyze [asset] [timeframe] - Detailed analysis for specific timeframe
/alltimeframes - Show all timeframe predictions
/causal [asset] [timeframe] - Show causal analysis
/backtest [asset] [timeframe] - Run backtest
/summary [asset] - Market summary
/chart [asset] [timeframe] - Generate chart
/subscribe [asset] - Subscribe to auto-updates
/unsubscribe - Stop auto-updates
/settings - Configure bot settings
/help - Show this message

**Example:** `/analyze BTC 1h`

⚠️ **Disclaimer**: Educational & Personal Use Only - NOT Financial Advice
"""
    await update.message.reply_text(welcome, parse_mode='Markdown')

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send help message"""
    help_text = """
📚 **Detailed Command Reference**

**Analysis Commands:**
/signals [asset] - View all timeframe signals
  Example: `/signals BTC`
  
/analyze [asset] [timeframe] - Detailed analysis
  Example: `/analyze ETH 1h`
  
/alltimeframes - Summary across all timeframes
  Example: `/alltimeframes SOL`

**Advanced Commands:**
/causal [asset] [timeframe] - What causes price movements?
  Example: `/causal BTC 15m`
  
/backtest [asset] [timeframe] - Historical performance
  Example: `/backtest ETH 5m`

**Utility Commands:**
/summary [asset] - Market overview
/chart [asset] [timeframe] - Generate chart
/subscribe [asset] - Auto-updates (every 5 min)
/unsubscribe - Stop auto-updates
/settings - Customize bot

**Timeframes:**
5m, 15m, 1h, 3h, 12h, 24h

**Assets:**
BTC, ETH, SOL (more coming soon)
"""
    await update.message.reply_text(help_text, parse_mode='Markdown')

async def signals_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Get signals for all timeframes"""
    args = context.args
    asset = args[0].upper() if args else 'BTC'
    
    await update.message.reply_text(f"🔄 Analyzing {asset} across all timeframes...")
    
    try:
        # Run analysis
        results = predictor.analyze_asset(asset)
        
        if not results:
            await update.message.reply_text(f"❌ No results for {asset}")
            return
        
        # Format response
        response = f"🎯 **{asset} - Trading Signals**\n\n"
        
        for timeframe, result in results.items():
            if 'entry_exit' in result and 'error' not in result['entry_exit']:
                ee = result['entry_exit']
                confidence = result['prediction'].get('confidence', 0)
                
                direction_emoji = "🟢" if ee['direction'] == 'BUY' else "🔴"
                
                response += f"""
⏰ **{timeframe}** {direction_emoji}
Direction: **{ee['direction']}**
Entry: ${ee['entry_price']:.2f}
Stop Loss: ${ee['stop_loss']:.2f}
Take Profit: ${ee['take_profit']:.2f}
Confidence: {confidence:.1%}
Risk/Reward: {ee.get('risk_reward_ratio', 0):.2f}
---
"""
        
        # Add summary
        bullish = sum(1 for r in results.values() 
                     if 'entry_exit' in r and 'error' not in r['entry_exit']
                     and r['entry_exit'].get('direction') == 'BUY')
        bearish = len(results) - bullish
        
        response += f"\n📊 **Summary**"
        response += f"\nBullish: {bullish} | Bearish: {bearish}"
        response += f"\nSentiment: {'🟢 BULLISH' if bullish > bearish else '🔴 BEARISH'}"
        
        await update.message.reply_text(response, parse_mode='Markdown')
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

async def analyze_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Analyze specific timeframe"""
    args = context.args
    
    if len(args) < 2:
        await update.message.reply_text(
            "Please specify asset and timeframe.\n"
            "Example: `/analyze BTC 1h`",
            parse_mode='Markdown'
        )
        return
    
    asset = args[0].upper()
    timeframe = args[1]
    
    # Validate timeframe
    valid_timeframes = ['5m', '15m', '1h', '3h', '12h', '24h']
    if timeframe not in valid_timeframes:
        await update.message.reply_text(
            f"Invalid timeframe. Choose from: {', '.join(valid_timeframes)}"
        )
        return
    
    await update.message.reply_text(f"🔍 Analyzing {asset} ({timeframe})...")
    
    try:
        # Run analysis
        results = predictor.analyze_asset(asset)
        
        if timeframe not in results:
            await update.message.reply_text(f"❌ No data for {asset} {timeframe}")
            return
        
        result = results[timeframe]
        
        if 'error' in result:
            await update.message.reply_text(f"❌ Error: {result['error']}")
            return
        
        # Format response
        pred = result['prediction']
        ee = result['entry_exit']
        
        response = f"""
📊 **{asset} - {timeframe} Analysis**

💰 **Price**
Current: ${pred['current_price']:.2f}
Predicted: ${pred['predicted_price']:.2f}
Change: {pred['change_pct']:+.2f}%
Confidence: {pred['confidence']:.1%}

🎯 **Entry/Exit Levels**
Direction: **{ee['direction']}**
Entry: ${ee['entry_price']:.2f}
Stop Loss: ${ee['stop_loss']:.2f}
Take Profit: ${ee['take_profit']:.2f}
Risk/Reward: {ee.get('risk_reward_ratio', 0):.2f}

📈 **Metrics**
Volatility: {pred.get('volatility', 0):.2%}
"""
        
        # Add causal factors if available
        if 'causal' in result and 'error' not in result['causal']:
            causal = result['causal']
            if 'top_features' in causal:
                top_features = causal['top_features'][:3]
                response += f"\n🔍 **Key Drivers**\n"
                for feature in top_features:
                    response += f"- {feature}\n"
        
        # Add backtest results if available
        if 'backtest' in result and result['backtest']['total_trades'] > 0:
            bt = result['backtest']
            response += f"""
📊 **Backtest**
Trades: {bt['total_trades']}
Win Rate: {bt['win_rate']:.1f}%
Avg Return: {bt['avg_return']:.2f}%
"""
        
        await update.message.reply_text(response, parse_mode='Markdown')
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

async def alltimeframes_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show summary across all timeframes"""
    args = context.args
    asset = args[0].upper() if args else 'BTC'
    
    await update.message.reply_text(f"📊 Getting summary for {asset}...")
    
    try:
        # Run analysis
        results = predictor.analyze_asset(asset)
        
        # Create inline keyboard for timeframe selection
        keyboard = []
        row = []
        for i, timeframe in enumerate(['5m', '15m', '1h', '3h', '12h', '24h']):
            if timeframe in results and 'error' not in results[timeframe]:
                # Get direction emoji
                ee = results[timeframe].get('entry_exit', {})
                emoji = "🟢" if ee.get('direction') == 'BUY' else "🔴" if ee.get('direction') == 'SELL' else "⚪"
                row.append(InlineKeyboardButton(f"{timeframe} {emoji}", callback_data=f"tf_{asset}_{timeframe}"))
            if len(row) == 3:
                keyboard.append(row)
                row = []
        if row:
            keyboard.append(row)
        
        # Add action buttons
        keyboard.append([
            InlineKeyboardButton("📊 Full Report", callback_data=f"report_{asset}"),
            InlineKeyboardButton("📈 Chart", callback_data=f"chart_{asset}")
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Initial message
        summary = f"📊 **{asset} - Multi-Timeframe Summary**\n\n"
        summary += f"Total Timeframes: {len(results)}\n"
        
        bullish = sum(1 for r in results.values() 
                     if 'entry_exit' in r and 'error' not in r['entry_exit']
                     and r['entry_exit'].get('direction') == 'BUY')
        summary += f"Bullish: {bullish} | Bearish: {len(results) - bullish}\n"
        
        avg_conf = np.mean([
            r['prediction'].get('confidence', 0)
            for r in results.values()
            if 'prediction' in r
        ]) if results else 0
        summary += f"Avg Confidence: {avg_conf:.1%}\n\n"
        
        summary += "Select a timeframe for details:"
        
        await update.message.reply_text(
            summary,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

async def causal_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show causal analysis"""
    args = context.args
    
    if len(args) < 2:
        await update.message.reply_text(
            "Please specify asset and timeframe.\n"
            "Example: `/causal BTC 1h`",
            parse_mode='Markdown'
        )
        return
    
    asset = args[0].upper()
    timeframe = args[1]
    
    await update.message.reply_text(f"🔍 Analyzing causal factors for {asset} ({timeframe})...")
    
    try:
        # Fetch data
        df = data_fetcher.fetch_all_timeframes(asset).get(timeframe)
        
        if df is None or df.empty:
            await update.message.reply_text(f"❌ No data for {asset} {timeframe}")
            return
        
        # Run causal analysis
        causal = causal_engine.identify_causal_factors(df)
        
        if 'error' in causal:
            await update.message.reply_text(f"❌ Error: {causal['error']}")
            return
        
        response = f"""
🔍 **Causal Analysis - {asset} ({timeframe})**

**Top Predictive Factors:**
"""
        for i, item in enumerate(causal.get('feature_importance', [])[:10], 1):
            response += f"{i}. {item['feature']}: {item['importance']:.3f}\n"
        
        if causal.get('leading_indicators'):
            response += f"\n**Leading Indicators:**\n"
            for indicator in causal['leading_indicators'][:5]:
                response += f"- {indicator['indicator']} (lag {indicator['lag']}): {indicator['correlation']:.3f}\n"
        
        await update.message.reply_text(response, parse_mode='Markdown')
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

async def backtest_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Run backtest"""
    args = context.args
    
    if len(args) < 2:
        await update.message.reply_text(
            "Please specify asset and timeframe.\n"
            "Example: `/backtest BTC 1h`",
            parse_mode='Markdown'
        )
        return
    
    asset = args[0].upper()
    timeframe = args[1]
    
    await update.message.reply_text(f"📊 Running backtest for {asset} ({timeframe})...")
    
    try:
        # Fetch data
        df = data_fetcher.fetch_all_timeframes(asset).get(timeframe)
        
        if df is None or df.empty:
            await update.message.reply_text(f"❌ No data for {asset} {timeframe}")
            return
        
        # Generate signals
        entry_signals, exit_signals = causal_engine.generate_signals(df)
        
        # Run backtest
        backtest = predictor.validation_engine.backtest_signals(
            df, entry_signals, exit_signals
        )
        
        if backtest['total_trades'] == 0:
            await update.message.reply_text("❌ No trades found in backtest")
            return
        
        response = f"""
📊 **Backtest Results - {asset} ({timeframe})**

**Performance Summary:**
Total Trades: {backtest['total_trades']}
Winning Trades: {backtest['winning_trades']}
Win Rate: {backtest['win_rate']:.1f}%
Average Return: {backtest['avg_return']:.2f}%
Total Return: {backtest['total_return']:.2f}%

**Recent Trades:**
"""
        # Show last 5 trades
        for trade in backtest['trades'][-5:]:
            profit_emoji = "🟢" if trade['return_pct'] > 0 else "🔴"
            response += f"{profit_emoji} {trade['entry_time'].strftime('%Y-%m-%d %H:%M')}: {trade['return_pct']:+.2f}%\n"
        
        await update.message.reply_text(response, parse_mode='Markdown')
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

async def summary_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Market summary"""
    args = context.args
    asset = args[0].upper() if args else 'BTC'
    
    await update.message.reply_text(f"📊 Getting summary for {asset}...")
    
    try:
        # Run analysis
        results = predictor.analyze_asset(asset)
        
        # Calculate summary
        total = len(results)
        successful = sum(1 for r in results.values() if 'error' not in r)
        bullish = sum(1 for r in results.values() 
                     if 'entry_exit' in r and 'error' not in r['entry_exit']
                     and r['entry_exit'].get('direction') == 'BUY')
        bearish = total - bullish
        
        avg_conf = np.mean([
            r['prediction'].get('confidence', 0)
            for r in results.values()
            if 'prediction' in r
        ]) if results else 0
        
        # Find best timeframe
        best_tf = max(
            [(tf, r['prediction'].get('confidence', 0)) 
             for tf, r in results.items()
             if 'prediction' in r],
            key=lambda x: x[1],
            default=(None, 0)
        )
        
        response = f"""
📊 **Market Summary - {asset}**

📈 **Overview**
Total Timeframes: {total}
Successful: {successful}
Bullish: {bullish} | Bearish: {bearish}
Avg Confidence: {avg_conf:.1%}

🎯 **Best Timeframe**
{best_tf[0]}: {best_tf[1]:.1%} confidence

⏰ **Last Update**
{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

📋 **Signals by Timeframe:**
"""
        for timeframe, result in results.items():
            if 'entry_exit' in result and 'error' not in result['entry_exit']:
                ee = result['entry_exit']
                emoji = "🟢" if ee['direction'] == 'BUY' else "🔴"
                response += f"{emoji} {timeframe}: {ee['direction']} ({result['prediction'].get('confidence', 0):.1%})\n"
        
        await update.message.reply_text(response, parse_mode='Markdown')
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

async def chart_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Generate and send chart"""
    args = context.args
    
    if len(args) < 2:
        await update.message.reply_text(
            "Please specify asset and timeframe.\n"
            "Example: `/chart BTC 1h`",
            parse_mode='Markdown'
        )
        return
    
    asset = args[0].upper()
    timeframe = args[1]
    
    await update.message.reply_text(f"📈 Generating chart for {asset} ({timeframe})...")
    
    try:
        # Import plotly
        import plotly.graph_objs as go
        from plotly.subplots import make_subplots
        import plotly.io as pio
        
        # Fetch data
        df = data_fetcher.fetch_all_timeframes(asset).get(timeframe)
        
        if df is None or df.empty:
            await update.message.reply_text(f"❌ No data for {asset} {timeframe}")
            return
        
        # Create chart
        fig = make_subplots(
            rows=3, cols=1,
            shared_xaxes=True,
            vertical_spacing=0.05,
            row_heights=[0.5, 0.25, 0.25],
            subplot_titles=(f'{asset} - {timeframe}', 'Volume', 'RSI')
        )
        
        # Price
        fig.add_trace(
            go.Candlestick(
                x=df.index[-100:],
                open=df['open'].iloc[-100:],
                high=df['high'].iloc[-100:],
                low=df['low'].iloc[-100:],
                close=df['close'].iloc[-100:],
                name='Price'
            ),
            row=1, col=1
        )
        
        # Volume
        fig.add_trace(
            go.Bar(
                x=df.index[-100:],
                y=df['volume'].iloc[-100:],
                name='Volume'
            ),
            row=2, col=1
        )
        
        # RSI
        rsi = causal_engine.calculate_rsi(df['close'])
        fig.add_trace(
            go.Scatter(
                x=df.index[-100:],
                y=rsi.iloc[-100:],
                name='RSI',
                line=dict(color='purple')
            ),
            row=3, col=1
        )
        fig.add_hline(y=70, line_dash="dash", line_color="red", row=3, col=1)
        fig.add_hline(y=30, line_dash="dash", line_color="green", row=3, col=1)
        
        fig.update_layout(
            height=600,
            template='plotly_dark',
            showlegend=True
        )
        
        # Convert to image
        img_bytes = pio.to_image(fig, format='png', width=800, height=600)
        
        # Send as photo
        await update.message.reply_photo(
            photo=BytesIO(img_bytes),
            caption=f"📊 {asset} - {timeframe} Chart"
        )
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error generating chart: {str(e)}")

async def subscribe_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Subscribe to auto-updates"""
    args = context.args
    asset = args[0].upper() if args else 'BTC'
    
    # Store subscription in context
    context.user_data['subscription'] = {
        'asset': asset,
        'active': True,
        'interval': 300  # 5 minutes
    }
    
    await update.message.reply_text(
        f"✅ Subscribed to {asset} updates!\n"
        f"🔄 Updates every 5 minutes\n"
        f"Use /unsubscribe to stop"
    )
    
    # Start background task for this user
    if 'subscription_task' not in context.user_data:
        context.user_data['subscription_task'] = True
        
        async def subscription_loop():
            while context.user_data.get('subscription', {}).get('active', False):
                try:
                    asset = context.user_data['subscription']['asset']
                    results = predictor.analyze_asset(asset)
                    
                    # Get best signal
                    best_tf = max(
                        [(tf, r) for tf, r in results.items() 
                         if 'entry_exit' in r and 'error' not in r['entry_exit']],
                        key=lambda x: x[1]['prediction'].get('confidence', 0),
                        default=(None, None)
                    )
                    
                    if best_tf[1]:
                        tf, result = best_tf
                        ee = result['entry_exit']
                        
                        message = f"""
🔄 **{asset} Update**

⏰ {tf}: {ee['direction']}
Entry: ${ee['entry_price']:.2f}
SL: ${ee['stop_loss']:.2f}
TP: ${ee['take_profit']:.2f}
Confidence: {result['prediction'].get('confidence', 0):.1%}
"""
                        await update.message.reply_text(message, parse_mode='Markdown')
                    
                    await asyncio.sleep(300)  # 5 minutes
                    
                except Exception as e:
                    logger.error(f"Subscription error: {e}")
                    await asyncio.sleep(60)
        
        # Start task
        asyncio.create_task(subscription_loop())

async def unsubscribe_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unsubscribe from auto-updates"""
    if 'subscription' in context.user_data:
        context.user_data['subscription']['active'] = False
        await update.message.reply_text("✅ Unsubscribed from updates")
    else:
        await update.message.reply_text("❌ You are not subscribed")

async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Bot settings"""
    keyboard = [
        [
            InlineKeyboardButton("⏰ Update Interval", callback_data="settings_interval"),
            InlineKeyboardButton("📊 Default Asset", callback_data="settings_asset")
        ],
        [
            InlineKeyboardButton("🔔 Alerts", callback_data="settings_alerts"),
            InlineKeyboardButton("📈 Chart Settings", callback_data="settings_chart")
        ],
        [
            InlineKeyboardButton("❌ Close", callback_data="settings_close")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "⚙️ **Bot Settings**\n\nSelect an option to configure:",
        parse_mode='Markdown',
        reply_markup=reply_markup
    )

# ============================================================
# CALLBACK HANDLERS
# ============================================================

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle button callbacks"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data.startswith('tf_'):
        # Timeframe selection
        _, asset, timeframe = data.split('_')
        
        # Run analysis
        results = predictor.analyze_asset(asset)
        
        if timeframe not in results:
            await query.edit_message_text(f"❌ No data for {asset} {timeframe}")
            return
        
        result = results[timeframe]
        
        if 'error' in result:
            await query.edit_message_text(f"❌ Error: {result['error']}")
            return
        
        pred = result['prediction']
        ee = result['entry_exit']
        
        response = f"""
📊 **{asset} - {timeframe}**

💰 Price: ${pred['current_price']:.2f}
Predicted: ${pred['predicted_price']:.2f}
Change: {pred['change_pct']:+.2f}%
Confidence: {pred['confidence']:.1%}

🎯 **Entry/Exit**
Direction: {ee['direction']}
Entry: ${ee['entry_price']:.2f}
SL: ${ee['stop_loss']:.2f}
TP: ${ee['take_profit']:.2f}
R/R: {ee.get('risk_reward_ratio', 0):.2f}
"""
        
        await query.edit_message_text(response, parse_mode='Markdown')
    
    elif data.startswith('report_'):
        # Full report
        asset = data.replace('report_', '')
        results = predictor.analyze_asset(asset)
        
        # Generate report
        report = predictor.generate_report(asset)
        await query.edit_message_text(
            f"📊 **{asset} Full Report**\n\n{report[:4000]}...\n\nUse /analyze for more details",
            parse_mode='Markdown'
        )
    
    elif data.startswith('chart_'):
        # Chart for asset
        asset = data.replace('chart_', '')
        
        keyboard = []
        for tf in ['5m', '15m', '1h', '3h', '12h', '24h']:
            keyboard.append([InlineKeyboardButton(tf, callback_data=f"chart_tf_{asset}_{tf}")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"📈 Select timeframe for {asset}:",
            reply_markup=reply_markup
        )
    
    elif data.startswith('chart_tf_'):
        _, _, asset, timeframe = data.split('_')
        
        # Generate and send chart
        # ... (same as chart_command)
    
    elif data.startswith('settings_'):
        setting = data.replace('settings_', '')
        
        if setting == 'interval':
            keyboard = [
                [InlineKeyboardButton("1 min", callback_data="interval_60")],
                [InlineKeyboardButton("5 min", callback_data="interval_300")],
                [InlineKeyboardButton("15 min", callback_data="interval_900")],
                [InlineKeyboardButton("30 min", callback_data="interval_1800")],
                [InlineKeyboardButton("1 hour", callback_data="interval_3600")],
                [InlineKeyboardButton("Back", callback_data="settings_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "⏰ Select update interval:",
                reply_markup=reply_markup
            )
        
        elif setting == 'asset':
            keyboard = [
                [InlineKeyboardButton("BTC", callback_data="asset_BTC")],
                [InlineKeyboardButton("ETH", callback_data="asset_ETH")],
                [InlineKeyboardButton("SOL", callback_data="asset_SOL")],
                [InlineKeyboardButton("Back", callback_data="settings_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "📊 Select default asset:",
                reply_markup=reply_markup
            )
        
        elif setting == 'close':
            await query.edit_message_text("⚙️ Settings closed")
    
    elif data.startswith('interval_'):
        interval = int(data.replace('interval_', ''))
        context.user_data['update_interval'] = interval
        
        await query.edit_message_text(f"✅ Update interval set to {interval//60} minutes")
    
    elif data.startswith('asset_'):
        asset = data.replace('asset_', '')
        context.user_data['default_asset'] = asset
        
        await query.edit_message_text(f"✅ Default asset set to {asset}")
    
    elif data == 'settings_back':
        # Back to settings
        await settings_command(update, context)

# ============================================================
# ERROR HANDLER
# ============================================================

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle errors"""
    logger.error(f"Update {update} caused error {context.error}")
    await update.message.reply_text("❌ An error occurred. Please try again later.")

# ============================================================
# MAIN
# ============================================================

def main():
    """Run the bot"""
    print("\n" + "="*60)
    print("🤖 MULTI-TIMEFRAME TRADING PREDICTOR - TELEGRAM BOT")
    print("Educational & Personal Use Only - NOT Financial Advice")
    print("="*60)
    
    # Create application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Add command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("signals", signals_command))
    application.add_handler(CommandHandler("analyze", analyze_command))
    application.add_handler(CommandHandler("alltimeframes", alltimeframes_command))
    application.add_handler(CommandHandler("causal", causal_command))
    application.add_handler(CommandHandler("backtest", backtest_command))
    application.add_handler(CommandHandler("summary", summary_command))
    application.add_handler(CommandHandler("chart", chart_command))
    application.add_handler(CommandHandler("subscribe", subscribe_command))
    application.add_handler(CommandHandler("unsubscribe", unsubscribe_command))
    application.add_handler(CommandHandler("settings", settings_command))
    
    # Add callback handler
    application.add_handler(CallbackQueryHandler(button_callback))
    
    # Add error handler
    application.add_error_handler(error_handler)
    
    # Start bot
    print("\n✅ Bot is running!")
    print("📍 Find your bot on Telegram")
    print("📊 Commands: /start to begin")
    print("Press Ctrl+C to stop\n")
    print("="*60)
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
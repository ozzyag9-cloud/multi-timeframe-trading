# ternary_algorithm.py
"""
Ternary Algorithm for Signal Validation
3-Stage Confirmation System:
1. Technical Confirmation (Indicators)
2. Pattern Confirmation (Price Action)
3. Volume Confirmation (Market Participation)

Only signals passing ALL 3 stages are considered VALID
"""

import pandas as pd
import numpy as np
from typing import Dict, Tuple, List
from scipy import stats

class TernarySignalFilter:
    """
    3-Stage Signal Validation Algorithm
    Eliminates false positives and negatives
    """
    
    def __init__(self):
        self.stage_weights = {
            'technical': 0.4,
            'pattern': 0.3,
            'volume': 0.3
        }
        
        self.threshold = 0.65  # Minimum composite score for valid signal
        
    def validate_signal(self, df: pd.DataFrame, 
                       signal_type: str, 
                       index: int) -> Dict:
        """
        Validate a signal using 3-stage ternary algorithm
        
        Args:
            df: OHLCV DataFrame
            signal_type: 'BUY' or 'SELL'
            index: Index of the signal in DataFrame
            
        Returns:
            Dict with validation results
        """
        
        # Stage 1: Technical Confirmation
        tech_score = self._technical_confirmation(df, signal_type, index)
        
        # Stage 2: Pattern Confirmation
        pattern_score = self._pattern_confirmation(df, signal_type, index)
        
        # Stage 3: Volume Confirmation
        volume_score = self._volume_confirmation(df, signal_type, index)
        
        # Composite Score
        composite = (
            tech_score * self.stage_weights['technical'] +
            pattern_score * self.stage_weights['pattern'] +
            volume_score * self.stage_weights['volume']
        )
        
        # Validation Decision
        is_valid = composite >= self.threshold
        
        return {
            'is_valid': is_valid,
            'composite_score': composite,
            'technical_score': tech_score,
            'pattern_score': pattern_score,
            'volume_score': volume_score,
            'signal_type': signal_type,
            'confidence': composite
        }
    
    def _technical_confirmation(self, df: pd.DataFrame, 
                               signal_type: str, 
                               idx: int) -> float:
        """Stage 1: Technical Indicator Confirmation"""
        scores = []
        
        # RSI Confirmation
        rsi = self._calculate_rsi(df['close'])
        if idx >= len(rsi):
            return 0.5
        
        rsi_value = rsi.iloc[idx]
        
        if signal_type == 'BUY':
            # Bullish: RSI oversold or rising from oversold
            if rsi_value < 30:
                scores.append(1.0)
            elif rsi_value < 40 and rsi_value > rsi.iloc[idx-1] if idx > 0 else False:
                scores.append(0.8)
            else:
                scores.append(0.3)
        else:  # SELL
            # Bearish: RSI overbought or falling from overbought
            if rsi_value > 70:
                scores.append(1.0)
            elif rsi_value > 60 and rsi_value < rsi.iloc[idx-1] if idx > 0 else False:
                scores.append(0.8)
            else:
                scores.append(0.3)
        
        # MACD Confirmation
        macd, signal, hist = self._calculate_macd(df['close'])
        if idx < len(macd):
            macd_value = macd.iloc[idx]
            signal_value = signal.iloc[idx]
            hist_value = hist.iloc[idx]
            
            if signal_type == 'BUY':
                # Bullish: MACD crossing above signal or positive histogram
                if macd_value > signal_value and hist_value > 0:
                    scores.append(1.0)
                elif macd_value > signal_value:
                    scores.append(0.7)
                elif hist_value > 0:
                    scores.append(0.5)
                else:
                    scores.append(0.2)
            else:  # SELL
                # Bearish: MACD crossing below signal or negative histogram
                if macd_value < signal_value and hist_value < 0:
                    scores.append(1.0)
                elif macd_value < signal_value:
                    scores.append(0.7)
                elif hist_value < 0:
                    scores.append(0.5)
                else:
                    scores.append(0.2)
        
        # Bollinger Bands Confirmation
        bb_upper, bb_middle, bb_lower = self._calculate_bollinger_bands(df['close'])
        if idx < len(bb_upper):
            close = df['close'].iloc[idx]
            
            if signal_type == 'BUY':
                # Bullish: Price near lower band or bouncing
                if close <= bb_lower.iloc[idx]:
                    scores.append(1.0)
                elif close < bb_middle.iloc[idx]:
                    scores.append(0.7)
                else:
                    scores.append(0.3)
            else:  # SELL
                # Bearish: Price near upper band or rejecting
                if close >= bb_upper.iloc[idx]:
                    scores.append(1.0)
                elif close > bb_middle.iloc[idx]:
                    scores.append(0.7)
                else:
                    scores.append(0.3)
        
        return np.mean(scores) if scores else 0.5
    
    def _pattern_confirmation(self, df: pd.DataFrame,
                             signal_type: str,
                             idx: int) -> float:
        """Stage 2: Pattern Recognition Confirmation"""
        scores = []
        
        # Check for candlestick patterns
        patterns = self._detect_candlestick_patterns(df, idx)
        
        if signal_type == 'BUY':
            bullish_patterns = ['hammer', 'inverted_hammer', 'bullish_engulfing', 
                              'morning_star', 'piercing_line']
            for pattern in bullish_patterns:
                if patterns.get(pattern, False):
                    scores.append(1.0)
                    break
            else:
                scores.append(0.3)
        else:  # SELL
            bearish_patterns = ['shooting_star', 'bearish_engulfing', 
                              'evening_star', 'hanging_man']
            for pattern in bearish_patterns:
                if patterns.get(pattern, False):
                    scores.append(1.0)
                    break
            else:
                scores.append(0.3)
        
        # Check for support/resistance
        support_resistance = self._detect_support_resistance(df, idx)
        
        if signal_type == 'BUY':
            # Buy near support
            if support_resistance.get('near_support', False):
                scores.append(1.0)
            elif support_resistance.get('support_distance', 0) < 0.02:
                scores.append(0.8)
            else:
                scores.append(0.4)
        else:  # SELL
            # Sell near resistance
            if support_resistance.get('near_resistance', False):
                scores.append(1.0)
            elif support_resistance.get('resistance_distance', 0) < 0.02:
                scores.append(0.8)
            else:
                scores.append(0.4)
        
        return np.mean(scores) if scores else 0.5
    
    def _volume_confirmation(self, df: pd.DataFrame,
                            signal_type: str,
                            idx: int) -> float:
        """Stage 3: Volume Confirmation"""
        scores = []
        
        if idx < 20:  # Need enough data
            return 0.5
        
        # Volume comparison to average
        avg_volume = df['volume'].iloc[idx-20:idx].mean()
        current_volume = df['volume'].iloc[idx]
        volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
        
        if signal_type == 'BUY':
            # Bullish: Volume should be above average
            if volume_ratio > 1.5:
                scores.append(1.0)
            elif volume_ratio > 1.2:
                scores.append(0.8)
            elif volume_ratio > 1.0:
                scores.append(0.5)
            else:
                scores.append(0.2)
        else:  # SELL
            # Bearish: Volume should be above average
            if volume_ratio > 1.5:
                scores.append(1.0)
            elif volume_ratio > 1.2:
                scores.append(0.8)
            elif volume_ratio > 1.0:
                scores.append(0.5)
            else:
                scores.append(0.2)
        
        # Volume trend
        if idx > 10:
            vol_trend = df['volume'].iloc[idx-5:idx].mean() / df['volume'].iloc[idx-10:idx-5].mean()
            
            if signal_type == 'BUY':
                # Volume increasing for bullish
                if vol_trend > 1.1:
                    scores.append(1.0)
                elif vol_trend > 1.0:
                    scores.append(0.7)
                else:
                    scores.append(0.3)
            else:  # SELL
                # Volume increasing for bearish
                if vol_trend > 1.1:
                    scores.append(1.0)
                elif vol_trend > 1.0:
                    scores.append(0.7)
                else:
                    scores.append(0.3)
        
        # Volume accumulation/distribution
        vwap = (df['close'] * df['volume']).cumsum() / df['volume'].cumsum()
        price_vs_vwap = df['close'].iloc[idx] / vwap.iloc[idx] if vwap.iloc[idx] > 0 else 1
        
        if signal_type == 'BUY':
            if price_vs_vwap < 0.98:  # Price below VWAP - accumulation
                scores.append(1.0)
            elif price_vs_vwap < 1.0:
                scores.append(0.7)
            else:
                scores.append(0.3)
        else:  # SELL
            if price_vs_vwap > 1.02:  # Price above VWAP - distribution
                scores.append(1.0)
            elif price_vs_vwap > 1.0:
                scores.append(0.7)
            else:
                scores.append(0.3)
        
        return np.mean(scores) if scores else 0.5
    
    def _calculate_rsi(self, prices: pd.Series, period: int = 14) -> pd.Series:
        """Calculate RSI"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def _calculate_macd(self, prices: pd.Series) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """Calculate MACD"""
        exp1 = prices.ewm(span=12, adjust=False).mean()
        exp2 = prices.ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        signal = macd.ewm(span=9, adjust=False).mean()
        hist = macd - signal
        return macd, signal, hist
    
    def _calculate_bollinger_bands(self, prices: pd.Series, 
                                   period: int = 20, 
                                   std_dev: float = 2.0) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """Calculate Bollinger Bands"""
        sma = prices.rolling(period).mean()
        std = prices.rolling(period).std()
        upper = sma + (std * std_dev)
        lower = sma - (std * std_dev)
        return upper, sma, lower
    
    def _detect_candlestick_patterns(self, df: pd.DataFrame, idx: int) -> Dict:
        """Detect candlestick patterns at specific index"""
        patterns = {}
        
        if idx < 1:
            return patterns
        
        open_price = df['open'].iloc[idx]
        high_price = df['high'].iloc[idx]
        low_price = df['low'].iloc[idx]
        close_price = df['close'].iloc[idx]
        
        body = abs(close_price - open_price)
        upper_wick = high_price - max(open_price, close_price)
        lower_wick = min(open_price, close_price) - low_price
        total_range = high_price - low_price
        
        # Hammer (Bullish)
        if (lower_wick > body * 2 and 
            upper_wick < body * 0.3 and 
            body < total_range * 0.3):
            patterns['hammer'] = True
        
        # Shooting Star (Bearish)
        if (upper_wick > body * 2 and 
            lower_wick < body * 0.3 and 
            body < total_range * 0.3):
            patterns['shooting_star'] = True
        
        # Bullish Engulfing
        if idx > 0 and close_price > df['open'].iloc[idx-1] and open_price < df['close'].iloc[idx-1]:
            patterns['bullish_engulfing'] = True
        
        # Bearish Engulfing
        if idx > 0 and close_price < df['open'].iloc[idx-1] and open_price > df['close'].iloc[idx-1]:
            patterns['bearish_engulfing'] = True
        
        # Doji
        if body < total_range * 0.1:
            patterns['doji'] = True
        
        # Spinning Top
        if body < total_range * 0.3 and upper_wick > body and lower_wick > body:
            patterns['spinning_top'] = True
        
        return patterns
    
    def _detect_support_resistance(self, df: pd.DataFrame, idx: int) -> Dict:
        """Detect support and resistance levels"""
        if idx < 20:
            return {'near_support': False, 'near_resistance': False}
        
        # Look back 20 periods
        window_high = df['high'].iloc[idx-20:idx].max()
        window_low = df['low'].iloc[idx-20:idx].min()
        current_price = df['close'].iloc[idx]
        
        # Check if near support (within 2%)
        near_support = current_price <= window_low * 1.02
        support_distance = (current_price - window_low) / current_price if current_price > 0 else 0
        
        # Check if near resistance (within 2%)
        near_resistance = current_price >= window_high * 0.98
        resistance_distance = (window_high - current_price) / current_price if current_price > 0 else 0
        
        return {
            'near_support': near_support,
            'near_resistance': near_resistance,
            'support_distance': support_distance,
            'resistance_distance': resistance_distance,
            'support_level': window_low,
            'resistance_level': window_high
        }
    
    def filter_signals(self, df: pd.DataFrame, 
                       entry_signals: pd.Series, 
                       exit_signals: pd.Series) -> Tuple[pd.Series, pd.Series]:
        """
        Apply ternary filter to entry and exit signals
        
        Returns:
            (filtered_entry_signals, filtered_exit_signals)
        """
        filtered_entry = pd.Series(0, index=df.index)
        filtered_exit = pd.Series(0, index=df.index)
        
        # Process entry signals
        for idx in df.index[entry_signals == 1]:
            # Find the position
            pos = df.index.get_loc(idx)
            
            # Validate signal
            validation = self.validate_signal(df, 'BUY', pos)
            
            if validation['is_valid']:
                filtered_entry.loc[idx] = 1
        
        # Process exit signals
        for idx in df.index[exit_signals == 1]:
            pos = df.index.get_loc(idx)
            
            validation = self.validate_signal(df, 'SELL', pos)
            
            if validation['is_valid']:
                filtered_exit.loc[idx] = 1
        
        return filtered_entry, filtered_exit
    
    def get_signal_quality(self, df: pd.DataFrame, 
                          signal_type: str, 
                          idx: int) -> Dict:
        """
        Get detailed signal quality metrics
        """
        validation = self.validate_signal(df, signal_type, idx)
        
        # Additional quality metrics
        quality_metrics = {
            'signal_strength': validation['composite_score'],
            'stage_scores': {
                'technical': validation['technical_score'],
                'pattern': validation['pattern_score'],
                'volume': validation['volume_score']
            },
            'recommendation': self._get_recommendation(validation),
            'risk_level': self._calculate_risk_level(validation)
        }
        
        return {**validation, **quality_metrics}
    
    def _get_recommendation(self, validation: Dict) -> str:
        """Get trading recommendation based on validation"""
        score = validation['composite_score']
        
        if score >= 0.85:
            return 'STRONG_SIGNAL'
        elif score >= 0.70:
            return 'MODERATE_SIGNAL'
        elif score >= 0.60:
            return 'WEAK_SIGNAL'
        else:
            return 'NO_SIGNAL'
    
    def _calculate_risk_level(self, validation: Dict) -> str:
        """Calculate risk level"""
        score = validation['composite_score']
        
        if score >= 0.80:
            return 'LOW'
        elif score >= 0.65:
            return 'MEDIUM'
        else:
            return 'HIGH'
#!/bin/bash
# start.sh - Start the application

set -e

echo "🚀 Starting Multi-Timeframe Trading Predictor"
echo "================================================"

# Activate virtual environment
source venv/bin/activate

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "❌ .env file not found. Run ./scripts/setup.sh first"
    exit 1
fi

# Load environment variables
export $(cat .env | grep -v '^#' | xargs)

# Check for Telegram token
if [ -z "$TELEGRAM_BOT_TOKEN" ] || [ "$TELEGRAM_BOT_TOKEN" = "your_bot_token_here" ]; then
    echo "⚠️  TELEGRAM_BOT_TOKEN not set in .env"
    echo "   Telegram bot will not work without token"
fi

echo ""
echo "📊 Starting Web Interface..."
echo "   http://localhost:5000"
echo ""
echo "🤖 Starting Telegram Bot..."
echo "   @YourBotName"
echo ""
echo "Press Ctrl+C to stop"
echo "================================================"

# Run with Python
python run.py --both
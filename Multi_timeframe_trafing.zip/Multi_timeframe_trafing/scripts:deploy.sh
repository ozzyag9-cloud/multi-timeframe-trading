#!/bin/bash
# deploy.sh - Production deployment script

set -e

echo "🚀 Deploying to Production"
echo "================================================"

# Configuration
APP_DIR="/app/multi-timeframe-trading"
SERVICE_NAME="trading-predictor"

# Pull latest code
echo "📥 Pulling latest code..."
cd $APP_DIR
git pull origin main

# Activate virtual environment
source venv/bin/activate

# Install dependencies
echo "📦 Installing dependencies..."
pip install -r requirements.txt

# Run migrations (if any)
echo "🔄 Running migrations..."

# Run tests
echo "🧪 Running tests..."
pytest tests/ -v

# Restart service
echo "🔄 Restarting service..."
sudo systemctl restart $SERVICE_NAME
sudo systemctl status $SERVICE_NAME --no-pager

echo ""
echo -e "${GREEN}✅ Deployment complete!${NC}"
echo "================================================"
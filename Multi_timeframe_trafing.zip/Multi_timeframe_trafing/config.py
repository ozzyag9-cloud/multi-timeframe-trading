# config.py
"""
Configuration for Multi-Timeframe Trading Predictor
"""

import os
from pathlib import Path

class Config:
    """Base configuration"""
    
    # Security
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-12345')
    
    # API Keys
    TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')
    
    # Assets and Timeframes
    DEFAULT_ASSET = 'BTC'
    DEFAULT_TIMEFRAME = '1h'
    SUPPORTED_ASSETS = ['BTC', 'ETH', 'SOL']
    SUPPORTED_TIMEFRAMES = ['5m', '15m', '1h', '3h', '12h', '24h']
    
    # Analysis Settings
    LOOKBACK_YEARS = 5
    UPDATE_INTERVAL = 60  # seconds
    
    # Paths
    BASE_DIR = Path(__file__).parent
    CACHE_DIR = BASE_DIR / 'cache'
    OUTPUT_DIR = BASE_DIR / 'outputs'
    TEMPLATE_DIR = BASE_DIR / 'templates'
    STATIC_DIR = BASE_DIR / 'static'
    
    # Create directories
    CACHE_DIR.mkdir(exist_ok=True)
    OUTPUT_DIR.mkdir(exist_ok=True)
    TEMPLATE_DIR.mkdir(exist_ok=True)
    STATIC_DIR.mkdir(exist_ok=True)
    
    # Web Interface
    WEB_HOST = '0.0.0.0'
    WEB_PORT = 5000
    WEB_DEBUG = True
    
    # CORS
    CORS_ORIGINS = ['*']
    
    # Logging
    LOG_LEVEL = 'INFO'
    LOG_FILE = BASE_DIR / 'trading_predictor.log'

class DevelopmentConfig(Config):
    """Development configuration"""
    WEB_DEBUG = True
    LOG_LEVEL = 'DEBUG'

class ProductionConfig(Config):
    """Production configuration"""
    WEB_DEBUG = False
    LOG_LEVEL = 'WARNING'
    CORS_ORIGINS = ['https://yourdomain.com']

# Select configuration
config = DevelopmentConfig()